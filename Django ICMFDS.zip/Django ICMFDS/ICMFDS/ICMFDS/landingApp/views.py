from django.shortcuts import render , HttpResponse
from django.http import HttpResponse
from tkinter.filedialog import askdirectory
from tkinter import Tk
import os , hashlib
from pathlib import Path
# Create your views here.

def index(request):
    return render(request, "landingpage.html")
def about(request):
    return render(request,'about.html')
def purpose(request):
    return render(request, "purpose.html")
def team(request):
    return render(request, "team.html")
def loginpage(request):
    # return HttpResponse("this is LogIn Page")
    return render(request, 'loginpage.html')
def scanningpage(request):
    return render(request, 'scanningpage.html')
def mainpythonfile(request):
    return render(request, 'mainpythonfile.py')