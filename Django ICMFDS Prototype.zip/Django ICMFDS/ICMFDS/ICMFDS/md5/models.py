from django.db import models

# Create your models here.

class hashing(models.Model):
    user_name= models.CharField(max_length=50)
    user_input_file= models.FileField(max_length=50)

