from django.contrib import admin
from md5.models import hashing
# Register your models here.
class fileAdmin(admin.ModelAdmin):
    list_display=('user_name','user_input_file')

admin.site.register(hashing,fileAdmin)