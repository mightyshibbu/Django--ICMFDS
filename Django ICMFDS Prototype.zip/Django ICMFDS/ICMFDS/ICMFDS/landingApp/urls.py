from django.contrib import admin
from django.urls import path
from landingApp import views
from django.contrib import admin
# from django.conf.urls import url
# from . import mainpythonfile

urlpatterns = [
    path("",views.index, name='home'),
    path("about",views.about, name='about'),
    path("purpose",views.purpose, name='purpose'),
    path("team",views.team, name='team'),
    path("loginpage",views.loginpage, name='loginpage'),
    path("scanningpage",views.scanningpage, name='scanningpage'),
    path("mainpythonfile",views.mainpythonfile, name='mainpythonfile'),
    path("startalgorithm",views.startalgorithm, name='startalgorithm'),
    path("/handleSignup",views.handleSignup, name='handleSignup')
]
