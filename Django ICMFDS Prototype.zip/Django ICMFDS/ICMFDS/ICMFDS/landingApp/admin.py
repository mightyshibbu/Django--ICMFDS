from django.contrib import admin
# Register your models here.

from .models import userdata
from .models import logins

admin.site.register(userdata)
admin.site.register(logins)
