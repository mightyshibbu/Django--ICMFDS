from django.db import models

# Create your models here.
class userdata(models.Model):
    user_name=models.CharField(max_length=64 , null=True, default="")
    user_office_id= models.IntegerField( null=True, default="")
    user_original_image=models.ImageField(upload_to ='landingApp\images' , null=True , default="")
    def __str__(self):
        return self.user_name
class database(models.Model):
    username=models.CharField(max_length=64, null=True, default="")
    firstname=models.CharField(max_length=64, null=True, default="")
    lastname=models.CharField(max_length=64, null=True, default="")
    email=models.EmailField(max_length=64, null=True, default="")
    password1=models.CharField(max_length=64, null=True, default="")
    password2=models.CharField(max_length=64, null=True, default="")
    image=models.ImageField(null=True, default="")
    def __str__(self):
        return self.firstname
class logins(models.Model):
    username=models.CharField(max_length=64, blank=True, null=True)
    password=models.CharField(max_length=64,null=True, default="" )
    def __str__(self):
        return self.username
  