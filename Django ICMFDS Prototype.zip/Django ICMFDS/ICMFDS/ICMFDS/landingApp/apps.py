from django.apps import AppConfig

class LandingappConfig(AppConfig):
    name = 'landingApp'

        