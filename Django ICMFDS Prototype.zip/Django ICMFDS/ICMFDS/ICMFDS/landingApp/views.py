from django.shortcuts import render , HttpResponse , redirect
from django.http import HttpResponse
from django.http import HttpResponse
from django.contrib.auth.models import User 
from tkinter.filedialog import askdirectory
from tkinter import Tk
import os , hashlib
from pathlib import Path
# Create your views here.

def index(request):
    return render(request, "landingpage.html")
def about(request):
    return render(request,'about.html')
def purpose(request):
    return render(request, "purpose.html")
def team(request):
    return render(request, "team.html")
def loginpage(request):
    # return HttpResponse("this is LogIn Page")
    return render(request, 'loginpage.html')
def scanningpage(request):
    return render(request, 'scanningpage.html')

def startalgorithm(request):
    print("HELLO WORLD")
    image= request.GET['input_image']
    return HttpResponse(image)

# def mainpythonfile(request):
#     database={
#         'name1':
#     }``

def mainpythonfile(request):
    if request.method == 'POST':
        file= request.POST['file']
        
    else:
        return HttpResponse("404 ERROR BURRRAH!")
 #   ````````````````````````````````````````````````````````
    Tk().withdraw()
    path =  askdirectory(title="Select DATABASE folder")

    file_list = os.walk(path)

    unique = dict()

    hashfile_list = []


    for root,folders,files in file_list:
        for file in files:
            path = Path(os.path.join(root,file))
            # MD5 in actio*n below
            fileHash = hashlib.md5(open(path,'rb').read()).hexdigest()   
            print(fileHash)
            hashfile_list.append(fileHash)

    print(hashfile_list) # The Data set is defined and is ready to get searched

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


    scannedfolder =  askdirectory(title="Select a folder containing DOCUMENT")
    file_list = os.walk(scannedfolder)
    unique = dict()

    for root,folders,files in file_list:
        for file in files:
            scannedfolder = Path(os.path.join(root,file))
            # MD5 in action below
            fileHash = hashlib.md5(open(scannedfolder,'rb').read()).hexdigest()   
            print(fileHash)
            photokey = fileHash

    if photokey in hashfile_list:
        str="** AUTHORIZED **"
        print("\n\n** AUTHORIZED **")
    else:
        str="** UN AUTHORIZED **"
        print("\n\n ** UN AUTHORIZED **")
    
    return HttpResponse(str)


def handleSignup(request):
    if request.method == 'POST':
        #pulling every data
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        image= request.POST['image']
        user_hashid = md5.new(image).hexdigest()
    else:
        return HttpResponse("404 ERROR BURRRAH!")
    #Check for errorenous inputs
    #..
    #Create User
    myuser = User.objects.create_user(username,email,pass1)
    myuser.first_name = fname
    myuser.last_name = lname
    myuser.save()
    message.success(request, "Your account has been succesfully created!")
    # return redirect('/about')
    return render(request, "landingpage.html")  